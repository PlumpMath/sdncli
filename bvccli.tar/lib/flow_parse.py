class Flowparse(object):
	pass
